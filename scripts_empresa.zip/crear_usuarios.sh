#!/bin/bash
# Crea usuarios desde un archivo de texto

USUARIOS="usuarios.txt"
while read usuario; do
    useradd -m "$usuario" -s /bin/bash
    echo "$usuario:Contraseña123" | chpasswd
    echo "Usuario $usuario creado."
done < "$USUARIOS"
