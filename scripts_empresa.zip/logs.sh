#!/bin/bash
# Guarda logs importantes del sistema en un archivo con fecha

FECHA=$(date +%F)
DESTINO="/var/log/backup_logs"
mkdir -p "$DESTINO"

journalctl -xe > "$DESTINO/syslog_$FECHA.log"
dmesg > "$DESTINO/dmesg_$FECHA.log"
last > "$DESTINO/lastlog_$FECHA.log"

echo "Logs guardados en $DESTINO"
