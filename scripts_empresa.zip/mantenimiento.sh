#!/bin/bash
# Actualiza el sistema y limpia paquetes innecesarios

apt update && apt upgrade -y
apt autoremove -y
apt autoclean

echo "Sistema actualizado y limpio."
