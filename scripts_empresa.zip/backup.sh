#!/bin/bash
# Backup comprimido de /etc y /home

DESTINO="/var/backups"
FECHA=$(date +%F)
mkdir -p "$DESTINO"

tar -czf "$DESTINO/etc_backup_$FECHA.tar.gz" /etc
tar -czf "$DESTINO/home_backup_$FECHA.tar.gz" /home

echo "Backups almacenados en $DESTINO"
