#!/bin/bash
# Muestra estado de CPU, memoria y disco

echo "=== USO DE CPU ==="
top -b -n1 | grep "Cpu(s)"

echo -e "\n=== MEMORIA ==="
free -h

echo -e "\n=== DISCO ==="
df -h

echo -e "\n=== USUARIOS CONECTADOS ==="
who
