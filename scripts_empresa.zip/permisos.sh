#!/bin/bash
# Asigna grupo "empresa" a todos los usuarios y cambia permisos

groupadd empresa

for user in $(cut -d: -f1 /etc/passwd | grep -E '^ana|^pedro|^lucas'); do
    usermod -aG empresa "$user"
    chown -R "$user:empresa" /home/$user
    chmod 750 /home/$user
    echo "Permisos aplicados a $user"
done
