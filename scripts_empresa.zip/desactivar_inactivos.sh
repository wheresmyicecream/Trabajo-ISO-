#!/bin/bash
# Desactiva usuarios inactivos por más de 30 días

dias=30
usuarios_inactivos=$(lastlog -b $dias | awk 'NR>1 && $NF!="**Never logged in**" {print $1}')

for u in $usuarios_inactivos; do
    usermod -L "$u"
    echo "Usuario $u bloqueado por inactividad"
done
